package net.leelink.compiler;

public class MyClass<T> {

}
