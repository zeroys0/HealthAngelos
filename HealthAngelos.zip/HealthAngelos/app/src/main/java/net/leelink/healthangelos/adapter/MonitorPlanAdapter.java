package net.leelink.healthangelos.adapter;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import net.leelink.healthangelos.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MonitorPlanAdapter extends  RecyclerView.Adapter<MonitorPlanAdapter.ViewHolder> {
    List<String> list;
    Context context;
    OnOrderListener onOrderListener;
    public MonitorPlanAdapter (List<String> list, Context context,OnOrderListener onOrderListener ) {
        this.list = list;
        this.context = context;
        this.onOrderListener = onOrderListener;
    }
    @NonNull
    @Override
    public MonitorPlanAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.monitor_plan_item, parent, false); // 实例化viewholder
        MonitorPlanAdapter.ViewHolder viewHolder = new MonitorPlanAdapter.ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MonitorPlanAdapter.ViewHolder holder, final int position) {
        holder.im_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOrderListener.onButtonClick(v,position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list==null?0:list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView im_edit;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            im_edit = itemView.findViewById(R.id.im_edit);
        }
    }
}
