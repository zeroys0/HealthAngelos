package net.leelink.healthangelos.adapter;

import android.view.View;

public interface OnOrderListener {
    void onItemClick(View view);
    void onButtonClick(View view, int position);
}
