package net.leelink.healthangelos.fragment;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import com.google.gson.Gson;

import net.leelink.healthangelos.R;
import net.leelink.healthangelos.activity.ChooseClassActivity;
import net.leelink.healthangelos.activity.ElectFenceActivity;
import net.leelink.healthangelos.adapter.MonitorPlanAdapter;
import net.leelink.healthangelos.adapter.OnOrderListener;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MonitorPlanFragment extends BaseFragment implements OnOrderListener {

    private RecyclerView monitor_plan_list;
    private MonitorPlanAdapter monitorPlanAdapter;
    @Override
    public void handleCallBack(Message msg) {

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_monitor_plan, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        init(view);

        return view;
    }

    public void init(View view){
        monitor_plan_list = view.findViewById(R.id.monitor_plan_list);
        List<String> list = new ArrayList<>();
        list.add("测试");
        list.add("测试2");
        monitorPlanAdapter = new MonitorPlanAdapter(list,getContext(),MonitorPlanFragment.this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext(),RecyclerView.VERTICAL,false);
        monitor_plan_list.setLayoutManager(layoutManager);
        monitor_plan_list.setAdapter(monitorPlanAdapter);

    }


    @Override
    public void onItemClick(View view) {

    }

    @Override
    public void onButtonClick(View view, int position) {
        View popView = getLayoutInflater().inflate(R.layout.view_rail_plan, null);
        LinearLayout ll_info = (LinearLayout) popView.findViewById(R.id.ll_info);
        LinearLayout ll_edit = (LinearLayout) popView.findViewById(R.id.ll_edit);
        LinearLayout ll_delete = (LinearLayout) popView.findViewById(R.id.ll_delete);

        final PopupWindow pop = new PopupWindow(popView,
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
        pop.setContentView(popView);
        pop.setOutsideTouchable(true);
        pop.setBackgroundDrawable(new BitmapDrawable());


        ll_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  监控计划详情
              //  startActivity(new Intent(mContext, ActivityShowMap.class).putExtra("data", new Gson().toJson(map)));
                pop.dismiss();
            }
        });
        ll_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  startActivity(new Intent(mContext, RailCreatePlanActivity.class).putExtra("type", 1).putExtra("info", new Gson().toJson(map)));
                //  编辑监控计划
                pop.dismiss();
            }
        });
        ll_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 删除监控计划
                pop.dismiss();
          //      deleteplan(Id);
            }
        });
        pop.showAsDropDown(view);
    }
}
