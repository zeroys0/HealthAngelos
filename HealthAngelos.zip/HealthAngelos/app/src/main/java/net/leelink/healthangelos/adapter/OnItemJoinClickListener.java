package net.leelink.healthangelos.adapter;

import android.view.View;

public interface OnItemJoinClickListener {
    void onItemAdd(View view, int position);
}
