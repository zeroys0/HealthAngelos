package net.leelink.healthangelos.fragment;

import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import net.leelink.healthangelos.R;
import net.leelink.healthangelos.adapter.MonitorLimitsAdapter;
import net.leelink.healthangelos.adapter.OnOrderListener;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MonitorLimitsFragment extends BaseFragment implements OnOrderListener {

    private RecyclerView monitor_limits_list;
    private MonitorLimitsAdapter monitorLimitsAdapter;

    @Override
    public void handleCallBack(Message msg) {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_monitor_limits, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        init(view);

        return view;
    }

    public void init(View view){
        monitor_limits_list = view.findViewById(R.id.monitor_limits_list);
        List<String> list = new ArrayList<>();
        list.add("测试");
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext(),RecyclerView.VERTICAL,false);
        monitorLimitsAdapter = new MonitorLimitsAdapter(list,getContext(),MonitorLimitsFragment.this);
        monitor_limits_list.setLayoutManager(layoutManager);
        monitor_limits_list.setAdapter(monitorLimitsAdapter);

    }

    @Override
    public void onItemClick(View view) {

    }

    @Override
    public void onButtonClick(View view, int position) {
        View popView = getLayoutInflater().inflate(R.layout.view_rail_scope, null);
        LinearLayout ll_edit = (LinearLayout) popView.findViewById(R.id.ll_edit);
        LinearLayout ll_delete = (LinearLayout) popView.findViewById(R.id.ll_delete);

        final PopupWindow pop = new PopupWindow(popView,
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
        pop.setContentView(popView);
        pop.setOutsideTouchable(true);
        pop.setBackgroundDrawable(new BitmapDrawable());

        ll_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  编辑监控范围
                pop.dismiss();
             //   editScope(map);
            }
        });
        ll_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 删除监控范围
                pop.dismiss();
             //   scopeInUse(Id);
            }
        });

        pop.showAsDropDown(view);
    }
}
