package net.leelink.healthangelos.receiver;

import cn.jpush.android.service.JCommonService;

public class PushService extends JCommonService {

}
