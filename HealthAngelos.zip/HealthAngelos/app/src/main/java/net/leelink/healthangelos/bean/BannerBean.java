package net.leelink.healthangelos.bean;

public class BannerBean  {

    /**
     * id : 1
     * imgPath : /img/903ee410971c4f41b0084b651ca12755.png
     */

    private String id;
    private String imgPath;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }
}
