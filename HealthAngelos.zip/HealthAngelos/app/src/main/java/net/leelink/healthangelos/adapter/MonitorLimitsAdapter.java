package net.leelink.healthangelos.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import net.leelink.healthangelos.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MonitorLimitsAdapter extends  RecyclerView.Adapter<MonitorLimitsAdapter.ViewHolder> {

    List<String> list;
    Context context;
    OnOrderListener onOrderListener;
    public MonitorLimitsAdapter (List<String> list, Context context,OnOrderListener onOrderListener ) {
        this.list = list;
        this.context = context;
        this.onOrderListener = onOrderListener;
    }
    @NonNull
    @Override
    public MonitorLimitsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.monitor_limits_item, parent, false); // 实例化viewholder
        MonitorLimitsAdapter.ViewHolder viewHolder = new MonitorLimitsAdapter.ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MonitorLimitsAdapter.ViewHolder holder, final int position) {
        holder.tv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOrderListener.onButtonClick(v,position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list==null?0:list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView tv_edit;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_edit = itemView.findViewById(R.id.tv_edit);
        }
    }
}
