package net.leelink.healthangelos.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import com.google.android.material.tabs.TabLayout;

import net.leelink.healthangelos.R;
import net.leelink.healthangelos.adapter.HomePagerAdapter;
import net.leelink.healthangelos.adapter.Pager2Adapter;
import net.leelink.healthangelos.app.BaseActivity;
import net.leelink.healthangelos.fragment.FirstLeadFragment;
import net.leelink.healthangelos.fragment.MonitorLimitsFragment;
import net.leelink.healthangelos.fragment.MonitorPlanFragment;
import net.leelink.healthangelos.fragment.SecondLeadFragment;

import java.util.ArrayList;
import java.util.List;

public class ElectFenceActivity extends BaseActivity {

    private TabLayout tabLayout;
    private ViewPager2 view_pager;
    private List<Fragment> fragments;
    private RelativeLayout rl_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elect_fence);
        init();

    }

    public void init(){
        rl_back = findViewById(R.id.rl_back);
        rl_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tabLayout = findViewById(R.id.tabLayout);
        view_pager = findViewById(R.id.view_pager);
        tabLayout.addTab(tabLayout.newTab().setText("监控计划"));
        tabLayout.addTab(tabLayout.newTab().setText("监控范围"));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                view_pager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        fragments = new ArrayList<>();
        fragments.add(new MonitorPlanFragment());
        fragments.add(new MonitorLimitsFragment());
        view_pager.setAdapter(new Pager2Adapter(this,fragments));
        view_pager.setCurrentItem(0);
        view_pager.setUserInputEnabled(false);
    }


}
