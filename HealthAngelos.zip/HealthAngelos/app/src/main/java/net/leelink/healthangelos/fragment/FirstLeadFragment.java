package net.leelink.healthangelos.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Message;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import net.leelink.healthangelos.R;
import net.leelink.healthangelos.activity.ChooseClassActivity;
import net.leelink.healthangelos.activity.ElectFenceActivity;
import net.leelink.healthangelos.activity.HouseDoctorActivity;

public class FirstLeadFragment extends  BaseFragment implements View.OnClickListener {
    private RelativeLayout rl_fast_cure,rl_elect_fence,rl_house_doctor;
    private PopupWindow popuPhoneW;
    private View popview;
    private TextView btn_cancel, btn_confirm;
    private boolean BIND_DOCTOR = true;

    @Override
    public void handleCallBack(Message msg) {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        init(view);
        popu_head();
        return view;
    }

    public void init(View view){
        rl_fast_cure = view.findViewById(R.id.rl_fast_cure);
        rl_fast_cure.setOnClickListener(this);
        rl_elect_fence = view.findViewById(R.id.rl_elect_fence);
        rl_elect_fence.setOnClickListener(this);
        rl_house_doctor = view.findViewById(R.id.rl_house_doctor);
        rl_house_doctor.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.rl_fast_cure: //极速问诊
                Intent intent = new Intent(getContext(), ChooseClassActivity.class);
                startActivity(intent);
                break;
            case R.id.rl_elect_fence:   //电子围栏
                Intent intent1 = new Intent(getContext(), ElectFenceActivity.class);
                startActivity(intent1);
                break;
            case R.id.rl_house_doctor:
                if(BIND_DOCTOR) {
                    Intent intent2 = new Intent(getContext(), HouseDoctorActivity.class);
                    startActivity(intent2);
                } else {
                    popuPhoneW.showAtLocation(rl_house_doctor, Gravity.CENTER, 0, 0);
                    backgroundAlpha(0.5f);
                }
                break;
            case R.id.btn_cancel:
                popuPhoneW.dismiss();
                break;
            case R.id.btn_confirm:
                popuPhoneW.dismiss();
                Toast.makeText(getContext(), "预约    ", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    //获取图片
    @SuppressLint("WrongConstant")
    private void popu_head() {
        // TODO Auto-generated method stub
        popview = LayoutInflater.from(getContext()).inflate(R.layout.popu_home_house_doctor, null);
        btn_cancel = (TextView) popview.findViewById(R.id.btn_cancel);
        btn_confirm = (TextView) popview.findViewById(R.id.btn_confirm);
        btn_cancel.setOnClickListener(this);
        btn_confirm.setOnClickListener(this);
        popuPhoneW = new PopupWindow(popview,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        popuPhoneW.setFocusable(true);
        popuPhoneW.setSoftInputMode(PopupWindow.INPUT_METHOD_NEEDED);
        popuPhoneW.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        popuPhoneW.setOutsideTouchable(true);
        popuPhoneW.setBackgroundDrawable(new BitmapDrawable());
        popuPhoneW.setOnDismissListener(new poponDismissListener());
    }

    /**
     * 设置添加屏幕的背景透明度
     *
     * @param bgAlpha
     */
    public void backgroundAlpha(float bgAlpha) {
        WindowManager.LayoutParams lp = getActivity().getWindow().getAttributes();
        lp.alpha = bgAlpha; // 0.0-1.0
        if (bgAlpha == 1) {
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);//不移除该Flag的话,在有视频的页面上的视频会出现黑屏的bug
        } else {
            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);//此行代码主要是解决在华为手机上半透明效果无效的bug
        }
        getActivity().getWindow().setAttributes(lp);
    }

    /**
     * 添加新笔记时弹出的popWin关闭的事件，主要是为了将背景透明度改回来
     *
     * @author cg
     */
    class poponDismissListener implements PopupWindow.OnDismissListener {

        @Override
        public void onDismiss() {
            // TODO Auto-generated method stub
            // Log.v("List_noteTypeActivity:", "我是关闭事件");
            backgroundAlpha(1f);
        }
    }
}
