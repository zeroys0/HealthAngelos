package net.leelink.healthangelos.util;

public class Urls {
//    public static final String WEBSITE = "http://api.llky.net:8888/sh/user/";
    public static final String WEBSITE = "http://221.238.204.114:8888/jk/healthAngel/";

    public static final String C_WEBSITE ="http://221.238.204.114:8888/sh/customer/";

//    public static final String WEB = "http://api.llky.net:8888/sh/";
    public static final String WEB = "http://192.168.16.91:8888/sh/";


    public static final String IMG_URL = "http://221.238.204.114:8888/files";
//    public static final String IMG_URL = "http://api.llky.net:8888/files";



    //发送短信验证码
    public static final String SEND = C_WEBSITE +"send";

    //注册
    public static final String REGISTER = C_WEBSITE + "regist";

    //密码登录
    public static final String LOGIN = WEBSITE+"login";

    //验证码登录
    public static final String LOGINBYCODE = WEBSITE +"loginByCode";

    //首页轮播图
    public static final String HOMEBANNER = WEBSITE +"homeBanner";

    //每日监测排名
    public static final String RANK = WEBSITE +"rank";

    //养老资讯
    public static final String NEWS = WEBSITE +"news";

    //极速诊询医生
    public static final String DOCTOR = WEBSITE +"docter";
}
