package net.leelink.healthangelos.adapter;

import android.view.View;

public interface OnClassListener {
    void onItemClick(int position,int type);
}
